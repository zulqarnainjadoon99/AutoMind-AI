from __future__ import annotations

import csv
import io
import json
import uuid
from datetime import datetime
from pathlib import Path

import streamlit as st

APP_NAME = "AutoMind AI"
DATA_DIR = Path("data")
TASKS_FILE = DATA_DIR / "tasks.json"

from core import WORKFLOWS, create_task, progress, status

def load_tasks() -> list[dict]:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if not TASKS_FILE.exists():
        return []
    try:
        data = json.loads(TASKS_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except (json.JSONDecodeError, OSError):
        return []

def save_tasks(tasks: list[dict]) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    TASKS_FILE.write_text(json.dumps(tasks, indent=2, ensure_ascii=False), encoding="utf-8")

st.set_page_config(page_title=APP_NAME, page_icon="🧭", layout="wide")
st.title("🧭 AutoMind AI")
st.caption("A personal workflow planner prototype for task breakdown, progress tracking, and reporting.")
st.info("Free prototype: workflow suggestions are currently template-based; no paid AI API is required. Do not enter passwords, private client data, or confidential information.")

tasks = load_tasks()

with st.sidebar:
    st.header("Navigation")
    page = st.radio("Choose a page", ["Dashboard", "Create workflow", "Manage workflow", "Reports"])
    st.divider()
    st.caption("AutoMind AI · MVP v2.0")

if page == "Dashboard":
    total = len(tasks)
    completed = sum(status(t) == "Completed" for t in tasks)
    active = sum(status(t) == "In progress" for t in tasks)
    c1, c2, c3 = st.columns(3)
    c1.metric("Total workflows", total)
    c2.metric("In progress", active)
    c3.metric("Completed", completed)

    if not tasks:
        st.subheader("Welcome")
        st.write("Create your first workflow to start tracking tasks.")
    else:
        st.subheader("Your workflows")
        for task in sorted(tasks, key=lambda t: t.get("created_at", ""), reverse=True):
            with st.container(border=True):
                left, right = st.columns([4, 1])
                left.markdown(f"**{task['title']}**")
                left.caption(f"{task['category']} · Priority: {task['priority']} · {status(task)}")
                left.progress(progress(task) / 100, text=f"{progress(task)}% complete")
                right.write(f"ID: `{task['id']}`")

elif page == "Create workflow":
    st.subheader("Create a workflow")
    with st.form("create_workflow_form", clear_on_submit=True):
        title = st.text_input("Workflow title", placeholder="e.g. Prepare monthly IT report")
        category = st.selectbox("Workflow type", list(WORKFLOWS.keys()))
        priority = st.selectbox("Priority", ["Low", "Medium", "High"])
        description = st.text_area("Description (optional)", placeholder="What needs to be achieved?")
        st.caption("A starter checklist will be generated from the selected workflow template.")
        submitted = st.form_submit_button("Create workflow", type="primary")
    if submitted:
        if not title.strip():
            st.error("Please enter a workflow title.")
        else:
            task = create_task(title, category, priority, description)
            tasks.append(task)
            save_tasks(tasks)
            st.success(f"Workflow created. ID: {task['id']}")
            st.rerun()

elif page == "Manage workflow":
    st.subheader("Manage a workflow")
    if not tasks:
        st.warning("No workflows yet. Create one first.")
    else:
        options = {f"{t['title']} · {t['id']}": t["id"] for t in tasks}
        selected_label = st.selectbox("Select workflow", list(options.keys()))
        selected_id = options[selected_label]
        task = next(t for t in tasks if t["id"] == selected_id)
        st.markdown(f"### {task['title']}")
        st.caption(f"{task['category']} · Priority: {task['priority']} · Created: {task['created_at']}")
        if task.get("description"):
            st.write(task["description"])
        st.progress(progress(task) / 100, text=f"{progress(task)}% complete")
        changed = False
        for i, step in enumerate(task["steps"]):
            new_value = st.checkbox(step["title"], value=step["done"], key=f"{task['id']}_{i}")
            if new_value != step["done"]:
                step["done"] = new_value
                changed = True
        if changed:
            save_tasks(tasks)
            st.rerun()
        st.divider()
        if st.button("Delete this workflow", type="secondary"):
            st.session_state["confirm_delete"] = selected_id
        if st.session_state.get("confirm_delete") == selected_id:
            st.warning("Are you sure? This cannot be undone.")
            confirm_col, cancel_col = st.columns(2)
            if confirm_col.button("Confirm delete", type="primary"):
                tasks = [t for t in tasks if t["id"] != selected_id]
                save_tasks(tasks)
                st.session_state.pop("confirm_delete", None)
                st.rerun()
            if cancel_col.button("Cancel"):
                st.session_state.pop("confirm_delete", None)
                st.rerun()

elif page == "Reports":
    st.subheader("Reports and export")
    if not tasks:
        st.warning("No workflows available to report.")
    else:
        rows = []
        for t in tasks:
            rows.append({
                "id": t["id"],
                "title": t["title"],
                "category": t["category"],
                "priority": t["priority"],
                "status": status(t),
                "progress_percent": progress(t),
                "created_at": t["created_at"],
                "description": t.get("description", ""),
                "completed_steps": sum(bool(s["done"]) for s in t["steps"]),
                "total_steps": len(t["steps"]),
            })
        st.dataframe(rows, use_container_width=True, hide_index=True)
        output = io.StringIO()
        writer = csv.DictWriter(output, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
        st.download_button("Download CSV report", output.getvalue(), "automind_report.csv", "text/csv")
        report_lines = ["AUTOMIND AI — WORKFLOW PROGRESS REPORT", f"Generated: {datetime.now():%Y-%m-%d %H:%M}", ""]
        for t in tasks:
            report_lines.extend([
                f"Workflow: {t['title']}",
                f"ID: {t['id']} | Category: {t['category']} | Priority: {t['priority']}",
                f"Status: {status(t)} | Progress: {progress(t)}%",
                "Steps:",
            ])
            report_lines.extend([f"  [{'x' if s['done'] else ' '}] {s['title']}" for s in t["steps"]])
            report_lines.append("")
        st.download_button("Download text report", "\n".join(report_lines), "automind_report.txt", "text/plain")

st.divider()
st.caption("Prototype note: this version uses predefined workflow templates, not a connected generative AI model.")

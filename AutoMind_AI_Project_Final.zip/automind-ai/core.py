"""Core workflow logic for AutoMind AI, independent of the web interface."""
from __future__ import annotations

import uuid
from datetime import datetime

WORKFLOWS = {
    "Project Coordination": [
        "Define objective and expected outcome",
        "List deliverables and deadlines",
        "Assign owners and responsibilities",
        "Track progress and blockers",
        "Review results and document lessons learned",
    ],
    "IT Support": [
        "Record the issue and affected user/device",
        "Check symptoms and reproduce the issue",
        "Try safe, documented troubleshooting steps",
        "Verify the fix with the user",
        "Record resolution and prevention notes",
    ],
    "Office Administration": [
        "Clarify the administrative request",
        "Collect required information and documents",
        "Complete the task and verify details",
        "Share the result with relevant people",
        "Archive records and note follow-up actions",
    ],
    "Report Preparation": [
        "Confirm the report purpose and audience",
        "Gather and validate source information",
        "Organize findings into clear sections",
        "Review facts, spelling, and formatting",
        "Export and share the final report",
    ],
    "General Task": [
        "Clarify the goal",
        "Break the work into small steps",
        "Complete the highest-priority step",
        "Review the outcome",
        "Record next actions",
    ],
}


def progress(task: dict) -> int:
    steps = task.get("steps", [])
    if not steps:
        return 0
    return round(sum(bool(step.get("done")) for step in steps) / len(steps) * 100)


def create_task(title: str, category: str, priority: str = "Medium", description: str = "") -> dict:
    title = title.strip()
    if not title:
        raise ValueError("Workflow title cannot be empty.")
    if category not in WORKFLOWS:
        raise ValueError(f"Unknown workflow category: {category}")
    if priority not in {"Low", "Medium", "High"}:
        raise ValueError(f"Unknown priority: {priority}")
    return {
        "id": uuid.uuid4().hex[:8],
        "title": title,
        "category": category,
        "priority": priority,
        "description": description.strip(),
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "steps": [{"title": name, "done": False} for name in WORKFLOWS[category]],
    }


def status(task: dict) -> str:
    percent = progress(task)
    return "Completed" if percent == 100 else ("In progress" if percent > 0 else "Not started")

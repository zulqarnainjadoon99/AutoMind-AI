import unittest
from core import WORKFLOWS, create_task, progress, status


class AutoMindTests(unittest.TestCase):
    def test_new_task_starts_at_zero(self):
        self.assertEqual(progress(create_task("Test", "General Task")), 0)

    def test_progress_after_one_step(self):
        task = create_task("Test", "General Task")
        task["steps"][0]["done"] = True
        self.assertEqual(progress(task), 20)

    def test_completed_task_is_100_percent(self):
        task = create_task("Test", "IT Support")
        for step in task["steps"]:
            step["done"] = True
        self.assertEqual(progress(task), 100)
        self.assertEqual(status(task), "Completed")

    def test_title_is_trimmed(self):
        self.assertEqual(create_task("  Demo  ", "General Task")["title"], "Demo")

    def test_workflow_templates_exist(self):
        self.assertIn("IT Support", WORKFLOWS)
        self.assertGreater(len(WORKFLOWS["General Task"]), 0)

    def test_empty_title_is_rejected(self):
        with self.assertRaises(ValueError):
            create_task("   ", "General Task")

    def test_invalid_category_is_rejected(self):
        with self.assertRaises(ValueError):
            create_task("Demo", "Not a category")


if __name__ == "__main__":
    unittest.main()

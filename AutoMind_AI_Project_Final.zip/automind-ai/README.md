# AutoMind AI — Workflow Planner Prototype

AutoMind AI is a free-to-run personal project prototype for creating workflows, tracking checklist progress, and exporting reports. It is built with Python and Streamlit.

## Current features
- Create workflows from starter templates for project coordination, IT support, office administration, report preparation, and general tasks
- Set task priority and add a description
- Track progress with checklists
- Dashboard with workflow status
- Export workflow reports as CSV and text
- Local JSON persistence in the project `data/` folder

## Important scope note
This version is a **template-based workflow planner prototype**. It does not currently connect to a generative AI model. The “AI” name is the project name, not a claim that a model is integrated. An AI model integration can be added and tested as a later feature.

## Run online for free
### Option A: Google Colab
1. Open https://colab.new/
2. Upload or clone this repository, or paste `app.py` into a notebook cell and use Streamlit with a suitable Colab tunnel only if you understand the security implications.
3. For a simpler browser workflow, use Streamlit Community Cloud (Option B).

### Option B: Streamlit Community Cloud
1. Push this repository to your GitHub account.
2. Open https://share.streamlit.io/
3. Sign in with GitHub and deploy the repository.
4. Select `app.py` as the main file.

Free-tier availability, limits, and account requirements are controlled by the providers and may change.

## Run locally (optional)
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Tests
The lightweight unit tests can be run with:
```bash
python -m unittest discover -s tests -v
```

## Data and privacy
Workflow data is stored in `data/tasks.json` where the app is running. On hosted free services, files may not persist across restarts or redeployments. Do not enter passwords, sensitive personal information, or confidential company data.

## Suggested CV entry (only after you have tested the deployed app)
**AutoMind AI — Workflow Planner Prototype** | Personal Project  
- Built a Python and Streamlit application for workflow creation, checklist-based progress tracking, and CSV/text report export.
- Implemented reusable workflow templates, JSON data persistence, and dashboard metrics.
- Added basic automated tests for task progress and workflow logic.

Only list features you have personally tested. Do not describe this prototype as a production AI system.
